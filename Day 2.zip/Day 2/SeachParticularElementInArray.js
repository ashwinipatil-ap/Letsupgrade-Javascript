//Q4. Program to display only elements containing 'a' in the term of array

array =["Apps","Apple","Animals","Fruits","Banana","Cat","Dog"];
for (var i in array) 
 {
    index = array[i].indexOf("A");
    if(index > -1){
     console.log(array[i]);
    }
 }