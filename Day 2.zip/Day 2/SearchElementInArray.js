//Q3. Program to search element in a array of strings

var array = [10, 25, 90, 80, 50];
var element = 50;
var found = array.find(function (element) {
return element > 0;
});
console.log(found);