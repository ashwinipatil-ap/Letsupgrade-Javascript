//Q1. Program to find particular character in a string

let str = "Welcome";
console.log(str);
console.log(str.indexOf("l"));