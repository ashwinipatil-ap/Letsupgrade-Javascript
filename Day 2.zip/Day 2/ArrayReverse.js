//Q5. Print an array in reverse order

var arr = [1,2,3,4,5];
arr.reverse();
console.log(arr);