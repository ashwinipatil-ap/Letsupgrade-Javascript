//Q2. Program to convert minutes to seconds

let minutes = 3;
seconds = minutes * 60;
console.log(minutes + " Min " + " into sec is " + seconds);