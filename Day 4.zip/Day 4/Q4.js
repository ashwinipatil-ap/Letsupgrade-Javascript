let Data = [
  {
    "name": "A",
    "age": "42",
    "country": "India",
    "hobbies": ["dancing", "singing"],
  },
  {
    "name": "B",
    "age": "98",
    "country": "India",
    "hobbies": ["dancing", "singing"],
  },
  {
    "name": "C",
    "age": "4",
    "country": "UK",
    "hobbies": ["dancing", "singing"],
  },
  {
    "name": "D",
    "age": "42",
    "country": "USA",
    "hobbies": ["dancing", "singing"],
  },
]

 function age() {
     Data.forEach(function (d) {
       if(d.age < 30){
        console.log(d.name+": "+d.age);
       }
     });
  }

  function Country() {
     Data.forEach(function (d) {
       if(d.country ==  "India"){
        console.log(d.name+": "+d.country);
       }
     });
  }