//**************************Q1*********************************************************************
function changeImage1() {
  const ele = document.getElementById("image");
  console.log(ele.id);
  const newUrl =
    "http://2.bp.blogspot.com/-UJBc6hHWIHU/UKh0ygNMTlI/AAAAAAAAAz4/7-hl1cpSTg0/s1600/pinkflower.jpg";

  ele.src = newUrl;
}

function changeImage2() {
  const ele = document.getElementById("image");
  console.log(ele.id);
  const newUrl =
    "http://4.bp.blogspot.com/-JlCmZSSJfAI/UBPllbsjn_I/AAAAAAAAACg/3LiLTDD0h20/s1600/Lotus+flower.jpg";

  ele.src = newUrl;
}

function changeImage3() {
  const ele = document.getElementById("image");
  console.log(ele.id);
  const newUrl =
    "https://tse2.mm.bing.net/th?id=OIP.GgRCKo5WjOaB5tofnQKHsgHaFC&pid=Api&P=0&w=240&h=164";

  ele.src = newUrl;
}

//*****************************************Q2************************************************************
function printValue() {
  const eles = document.getElementsByClassName("name1");
  console.log(eles[0].value);
  document.getElementById("name2").value = eles[0].value;
}

//*****************************************Q3************************************************************
