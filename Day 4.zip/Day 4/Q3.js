let Data = [
  {
    "name": "A",
    "age": "42",
    "country": "India",
    "hobbies": ["dancing", "singing"],
  },
  {
    "name": "B",
    "age": "98",
    "country": "India",
    "hobbies": ["dancing", "singing"],
  },
  {
    "name": "C",
    "age": "4",
    "country": "UK",
    "hobbies": ["dancing", "singing"],
  },
  {
    "name": "D",
    "age": "42",
    "country": "USA",
    "hobbies": ["dancing", "singing"],
  },
]

Data.forEach(function (d) {
   console.log("**********************************************************")
   console.log(d.name);
   console.log(d.age);
   console.log(d.country);
   d.hobbies.forEach(function (h) {
    console.log(h);
   });
 });